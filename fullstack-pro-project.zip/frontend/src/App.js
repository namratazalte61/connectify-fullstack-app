import React, { useState } from "react";
import axios from "axios";

function App() {
  const [form, setForm] = useState({name:"", email:"", message:""});

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/api/contact", form);
    alert("Message Saved!");
  };

  return (
    <div style={{textAlign:"center"}}>
      <h1>Pro Startup 🚀</h1>
      <form onSubmit={handleSubmit}>
        <input placeholder="Name" onChange={e=>setForm({...form,name:e.target.value})}/><br/>
        <input placeholder="Email" onChange={e=>setForm({...form,email:e.target.value})}/><br/>
        <textarea placeholder="Message" onChange={e=>setForm({...form,message:e.target.value})}/><br/>
        <button>Send</button>
      </form>
    </div>
  );
}
export default App;
