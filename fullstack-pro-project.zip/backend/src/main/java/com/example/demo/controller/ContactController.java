package com.example.demo.controller;
import com.example.demo.model.Contact;
import com.example.demo.repository.ContactRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api")
public class ContactController {

 private final ContactRepository repo;
 public ContactController(ContactRepository repo){this.repo=repo;}

 @PostMapping("/contact")
 public Contact save(@RequestBody Contact c){
  return repo.save(c);
 }

 @GetMapping("/contacts")
 public List<Contact> getAll(){
  return repo.findAll();
 }
}
